# Validated routing checkpoint — 19 October 2026

WORK IN PROGRESS — final high-speed review and manufacturing outputs pending.

The current saved PCB has passed native KiCad 10.0.7 DRC with zero errors, zero warnings, zero unconnected items and zero schematic parity issues. The schematic ERC has zero violations. No design-rule limits were relaxed and no new exclusions were added. Reports are in validation/.

All components are placed and all nets connected. The four-layer arrangement is front signal / inner power / inner ground / back signal; the ground layer carries no signal traces. The USB pair is matched at approximately 95.897 mm per leg, on the back layer without vias. Fifty-two vias were moved outside small component pads with short connections, and unused track tails were removed.

The P4-to-C6 SDIO bus is undergoing length and routing review. Experimental bus revisions are kept outside this project until validated. This checkpoint must not be represented as full high-speed sign-off or the final manufacturing release.

The BOM has 62 assembly groups (34 Basic, 28 Extended) and 178 fitted components per board. U1 C54540373 was unavailable in JLC's catalogue at the last stock check on 18 October. Six local decoupling capacitors use stocked Basic 0402 parts; the schematic, PCB and BOM match.

Existing Gerbers and positions are stale. Do not order from them. They will be regenerated after the remaining review is finished.
