# Revision in progress — 18 October 2026

The schematic is updated, with ERC passing. The PCB is an unfinished layout, not ready to manufacture. The original project is preserved in P4-Audio-TFT-before-revision-20261018.zip.

Implemented: latest Waveshare outline, connectors, FPCs, audio and RTC circuits; separate P4/C6 schematic; C6 on bottom edge with rounded R1mm antenna notch and all-layer keepout; C6 programming header retained; side-B TPS2553 input protection ahead of SW3, with 60.4k 1% resistor for a conservative 500mA maximum; switched 5V feeds the Waveshare LD39150 LDO and backlight.

Stack: F.Cu signal / In1.Cu power / In2.Cu ground / B.Cu signal. Power connections use local short traces to vias and planes. Inner power layer may be used for signal routes only if unavoidable. Ground plane remains reserved for ground.

The P4 and most new support parts are still staged to the right of the board. Their placement, decoupling positions and routing remain unfinished. Old module track/via tails require cleanup. Inner signal routes removed during stack conversion need rerouting on outer layers. No production outputs are valid for this revision yet.

BOM sourcing completed: 60 JLC assembly groups, 32 Basic and 28 Extended, plus manual headers and mounting holes. All selected assembly parts have displayed stock sufficient for five boards except U1 ESP32-P4NRW32X C54540373, which is out of stock. Do not place an assembly order until U1 availability and PCB layout/routing are resolved.

The BOM uses the compatible C6-MINI-1-H4 because N4 stock is insufficient. The flash footprint is corrected to WSON-8 8x6mm, L2 uses an available 1uH part with its matching footprint, and the unavailable EMH4 reset pair is replaced by two S8050 transistors and two 10k resistors. Prices and stock checked 18 October 2026. Assembly CSV excludes manually fitted programming/RTC headers and mounting holes. No placement file or Gerbers have been generated for this unfinished revision.
