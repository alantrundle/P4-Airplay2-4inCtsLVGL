# PCB revision in progress — 18 October 2026

All 59 previously staged core components have now been placed on the PCB, on side B, clear of the TFT face. The FPC connectors remain in their established positions; explicit component keepouts reserve the LCD and touch cable approaches.

The processor-side fanout of the former Waveshare module has been removed for rerouting to the separate P4. Connections within the audio circuits have been retained. Power-plane taps and high-speed routing are being checked. The PCB is NOT ready for manufacture: the routing and final DRC are still in progress. No new production placement/Gerber outputs have been issued.

Four layers: F signal / In1 power / In2 ground / B signal. The intended 1.6 mm fabrication build is JLC04161H-3313 (0.0994 mm outer prepregs, er 4.1), to support fine-pitch controlled-impedance routing. Confirm this build with JLC when ordering.

C116 (1uF) now bypasses the P4 VDDO_FLASH output rather than duplicating the main 3V3 rail bypass. Its BOM code and value are unchanged.

The sourcing BOM remains 32 Basic and 28 Extended assembly groups. Required P4 C54540373 is out of stock at the latest check; do not order assembly until both stock and layout/routing are resolved. Existing BOM quantities remain valid.

Original project backup: P4-Audio-TFT-before-revision-20261018.zip. Previous layout checkpoint: P4-Audio-TFT-before-core-placement-20261018.zip.
