# Routing checkpoint — 18 October 2026

WORK IN PROGRESS — DO NOT FABRICATE YET.

The current PCB and schematic include the placed discrete P4/C6 circuits and subsequent routing, four-layer planes, matched USB pair, connector layout, antenna cutout and local P4 decoupling revision. Six local capacitors now use stocked Basic 0402 parts: C101/C115/C118 C1525 and C99/C102/C116 C52923. The schematic, library and sourcing BOM match these packages.

The saved routing checkpoint has no clearance/shorting errors in its native KiCad DRC. It still has 8 connection gaps and 36 warnings to resolve. Routing and silkscreen cleanup are continuing; this is not the finished manufacturing package. See validation/routing-checkpoint-drc.json.

The sourcing BOM contains 62 assembly groups: 34 Basic and 28 Extended, 178 fitted components per board. U1 ESP32-P4NRW32X C54540373 remains out of stock in JLC's catalogue. Do not place an assembly order until sourcing and PCB validation are complete.

Existing Gerbers and positions are from an older revision. They must be regenerated after final validation. production/bom.csv is the updated sourcing BOM only.
