# Ordering hold: touch ribbon

The supplied 3.95-inch ILI9488 PDF verifies the 40-pin LCD interface, 60.88 x 94.57 mm glass, 0.5 mm ribbon pitch and backlight specification. The supplier email corrects LCD pin 10 to DC/A0 and pin 11 to SPI clock; the circuit follows that correction.

The exact six-pin capacitive-touch drawing was not supplied. The email mentions a CTP PNG/DWG but does not contain those attachments. The current TS1 connection is 1=3.3V, 2=SDA, 3=SCL, 4=INT, 5=RESET, 6=GND. This mapping is retained but NOT verified for the purchased display. Incorrect supply/ground order could damage the touch controller.

Candidate AliExpress item 1005006487871400 could not be inspected because the browser site-safety policy blocks the page. No compatibility conclusion has been drawn from that listing. Obtain its dimension drawing, touch pinout and contact-side information as an image or PDF before ordering this carrier.

The bundle contains the reviewed design and manufacturing exports, but is not an unconditional release to manufacture. Physical ribbon folding, socket height, plug clearance and powered operation require a prototype check. KiCad reports do not establish these properties. JLC stock has not been reserved, and its final assembly preview still needs checking after uploading the matching new Gerbers, BOM and CPL.
